package sample.scene1;

public class Sample1 {
}
