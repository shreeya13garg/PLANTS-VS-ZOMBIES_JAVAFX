package sample.scene1;

public class Levels {
}
